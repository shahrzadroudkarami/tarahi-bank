# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

moshtarak ={
    "اسم":"",
    "رمز":"",
    "مبلغ":"",
}
print("کارت خود را وارد کنید")
name= input(("نام خود را وارد کنید:"))
password = input(("رمز خود را وارد کنید:"))
x = input (("رمز خود را تکرار کنید:"))
if  x == password :
    print("خوش امدید")
    b = input (("مبلغی را برای ایجاد حساب وارد کنید:"))
    moshtarak["اسم"]=name
    moshtarak["رمز"]=password
    moshtarak["مبلغ"]=b
    print ("حساب ایجاد شد")
    print(("گزینه مورد نظر را انتخاب کنید"))
    print(("1.کارت به کارت"))
    print(("2.برداشت وجه"))
    print(("3.واریز وجه "))
    print(("4.تغییر رمز"))
    print(("5.دریافت موجودی"))
    print(("6.پایان تراکنش"))       
    y= ""
    while y!=6 :
        print(("گزینه مورد نظر را انتخاب کنید"))
        y = input ()
        if y=="1" :
            cartnum = input (("شماره کارت 16 رقمی مقصد را وارد کنید"))
            a = len(cartnum)
            if a<16 :
                print("شماره کارت اشتباه است")
            c = input (("مبلغ مورد نظر را وارد کنید:"))
            if int(c)>int(b):
                print("موجودی کافی نیست")
            else :
                z = int(b)-int(c)
                print(str(z)+"کارت به کارت انجام شد"+" مانده حساب شما برابر با")
        b = z
        moshtarak["مبلغ"]=b
        if y=="2" :
            d = input (("مبلغ مورد نظر را وارد کنید:"))
            if int(c)>int(b):
                print("موجودی کافی نیست")
            else :
                z = int(b)-int(d)
                print(str(z)+"برداشت با موفقیت انجام شد"+" مانده حساب شما برابر با")
        b = z
        moshtarak["مبلغ"]=b
        if y=="3" :
            d = input (("مبلغ مورد نظر را وارد کنید:"))
            z = int(b)+int(d)
            print(str(z)+"واریز انجام شد"+" مانده حساب شما برابر با")
        b = z
        moshtarak["مبلغ"]=b
        if y=="4" :
            d = input (("رمزفعلی را وارد کنید:"))
            if d == password :
                s = input (("رمز جدید را وارد کنید:"))
                sn = input (("رمز جدید را تکرار کنید")) 
                if s==sn :
                    print("رمز با موفقیت تغییر یافت")
                    password=s 
                    moshtarak["رمز"]=password
                else :
                    print ("تکرار رمز اشتباه است ")
            else :
                print("رمز نادرست است")
       
        if y=="5" :
            print ("موجودی حساب شما برابر است با "+str(b))
        if y=="6" :
            
            print ("روز خوبی داشته باشید")
            break

else :
    print("رمز نادرست است")
    
